import dotenv from "dotenv";
dotenv.config();

const API_KEY = process.env.GEMINI_API_KEY;
const BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models";

async function checkModels() {
  console.log("--- 🔍 DIAGNOSTIC START ---");
  
  if (!API_KEY) {
    console.error("❌ No API Key found in .env");
    return;
  }

  const url = `${BASE_URL}?key=${API_KEY}`;
  
  try {
    console.log(`📡 Pinging Google API to list available models...`);
    
    // Direct fetch call, bypassing the SDK
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    console.log("\n✅ SUCCESS! The API Key is working.");
    console.log("Here are the EXACT model names your key can use:\n");

    // Filter for models that support 'generateContent'
    const validModels = data.models
      .filter(m => m.supportedGenerationMethods.includes("generateContent"))
      .map(m => m.name.replace("models/", "")); // Clean up the name

    console.table(validModels);

    console.log("\n👇 RECOMMENDED FIX:");
    console.log(`Update your code to use one of the names above, specifically: "${validModels[0]}"`);

  } catch (error) {
    console.error("\n❌ CONNECTION FAILED");
    console.error("The raw API request failed. This means the issue is likely with the API Key, Network, or Region, not the code.");
    console.error("Error details:", error.message);
  }
}

checkModels();