import { GoogleGenerativeAI } from "@google/generative-ai";
import dotenv from "dotenv";
dotenv.config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

async function listModels() {
  try {
    const modelResponse = await genAI.getGenerativeModel({ model: "gemini-pro" });
    // Note: The SDK doesn't always expose a direct list method easily in older versions,
    // but a wrong model name usually suggests the right ones in the error. 
    // However, we can try to force a simple generation on the most standard model:
    console.log("Checking connection with 'gemini-pro'...");
    const result = await modelResponse.generateContent("Test");
    console.log("✅ 'gemini-pro' works!");
  } catch (error) {
    console.log("❌ 'gemini-pro' failed.");
    console.log("Error details:", error.message);
  }
}

listModels();