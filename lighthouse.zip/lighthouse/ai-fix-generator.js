import { GoogleGenerativeAI } from "@google/generative-ai";
import fs from "fs";
import path from "path";
import dotenv from "dotenv";

dotenv.config();

/* ---------------- INIT CLIENT ---------------- */
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// 'gemini-1.5-flash' is the correct model name for the latest version
const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

/* ---------------- LLM CALL ---------------- */
async function callLLM(prompt) {
  console.log("--- Calling Gemini API for AI Analysis ---");

  try {
    const result = await model.generateContent({
      // 1. Correct: contents must be an array of objects
      contents: [
        {
          role: "user",
          parts: [{ text: prompt }]
        }
      ],
      // 2. Correct: Use 'generationConfig' (not 'config')
      generationConfig: {
        responseMimeType: "application/json"
      }
    });

    // 3. Correct: Retrieve response object, then get text
    const response = await result.response;
    const text = response.text().trim();

    // 4. Cleanup: Remove markdown code fences if present
    const cleanText = text.replace(/```json|```/g, "").trim();

    return JSON.parse(cleanText);

  } catch (error) {
    // Better error logging to see exactly what went wrong
    console.error("API Call Failed Details:", JSON.stringify(error, null, 2));
    throw error;
  }
}

/* ---------------- PATHS ---------------- */
const REPORT_DIR = path.join(process.cwd(), "lhci-reports");
const REPORT_FILE = path.join(REPORT_DIR, "lighthouse-report.json");
const OUTPUT_FILE = path.join(REPORT_DIR, "ai-recommendation.json");

/* ---------------- MAIN ---------------- */
async function run() {
  if (!fs.existsSync(REPORT_FILE)) {
    console.error("❌ Lighthouse report not found at:", REPORT_FILE);
    return;
  }

  // Read and parse the report
  const rawData = fs.readFileSync(REPORT_FILE, "utf-8");
  const report = JSON.parse(rawData);

  // Filter for failed audits (score < 0.9)
  const failedAudits = Object.values(report.audits).filter(
    a => a.score !== null && a.score < 0.9
  );

  if (failedAudits.length === 0) {
    console.log("✅ No failed audits found! Great job.");
    return;
  }

  const prompt = `
You are a senior web performance engineer.

Analyze the Lighthouse failures below.
Identify the TOP 5 most impactful issues based on performance impact.
Each issue must be distinct and non-overlapping.
Provide a scalable, framework-agnostic fix that applies to ANY web application.

Return ONLY valid JSON.
No markdown.
No explanation text.
Return EXACTLY 5 items.

JSON format:
{
  "recommendations": [
    {
      "issue": "string",
      "principle": "string",
      "fix": "string",
      "isScalable": true
    }
  ]
}

FAILED AUDITS:
${JSON.stringify(failedAudits.slice(0, 10), null, 2)}
`;

  try {
    const aiResult = await callLLM(prompt);

    fs.writeFileSync(
      OUTPUT_FILE,
      JSON.stringify(
        {
          timestamp: new Date().toISOString(),
          aiRecommendation: aiResult,
        },
        null,
        2
      )
    );

    console.log("✅ AI fix generated successfully");
    console.log("Saved to:", OUTPUT_FILE);
  } catch (e) {
    console.error("❌ AI Execution Failed:", e.message);
  }
}

run();